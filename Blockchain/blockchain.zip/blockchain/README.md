# Blockchain

## API documentation

Format of received data to mine:
```json
{
    "data_hash": "data_hash",
    "prediction": true,
    "signature": "guesser-signature"
}
```

Format of data stored in chain:
```json
{
    "data_hash": "data_hash",
    "prediction": true,
    "signature": "guesser-signature"
}
```

## To do list

### Better block validation

Do not allow the same user to vote twice for the same hash-content.

### Reward system

Each node should be able to calculate the number of points of each user.

Do not consider the latest blocks (6 to match the bitcoin blockchain decision).

To calculate the number of points:

For each block:
- Store signature in a map, and put an object containing the current number of points, the list hash-contents they predicted True, idem with False
- Update the content of each user as the chain grows


### Debug

**State :** without rewards

- Test with one node:
  - [x] Model correctly stored
  - [x] Mining process in parallel
  - [x] Mined block correct 
- Test with one miner and passive one:
  - [x] Receiver accept incoming block and update correctly his list of model to mine
  - [x] Test with late node (should accept chain with several blocks already inside)
- Test with 2 miners:
  - [ ] Both update their chain correctly
  - [ ] Both update their list of model correctly
- Test with several nodes:
  - [ ] Everything should be fine by now
