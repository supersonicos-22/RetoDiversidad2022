import base64
import json
import sys

from Crypto.PublicKey import RSA
from flask import Flask, request, jsonify
from models.BlockData import BlockData, ResponseException
from blockchain.BlockChain import Blockchain
from blockchain.Block import BlockHeader, Block
from models.BlockDto import BlockDto
from node.HostNode import HostNode
from blockchain import FILENAME
from os.path import exists
from commons.utils import get_timestamp, generate_key_pair
from commons import KNOWN_PORT, KNOWN_IP, KNOWN_PUB_KEY
from models.NodeDto import NodeDto
from node import PUB_KEY_FILENAME, PRIVATE_KEY_FILENAME


app = Flask(__name__)


def init_key_pair():
    if exists(PUB_KEY_FILENAME) and exists(PRIVATE_KEY_FILENAME):
        with open(PUB_KEY_FILENAME, "rb") as f:
            public_key = RSA.importKey(f.read())
        with open(PRIVATE_KEY_FILENAME, "rb") as f:
            private_key = RSA.importKey(f.read())
        return public_key, private_key
    else:
        public_key, private_key = generate_key_pair()
        with open(PUB_KEY_FILENAME, "wb") as f:
            f.write(public_key)
        with open(PRIVATE_KEY_FILENAME, "wb") as f:
            f.write(private_key)
        return RSA.importKey(public_key), RSA.importKey(private_key)


def init_host():
    public_key, private_key = init_key_pair()
    return HostNode(sys.argv[5], int(sys.argv[3]), public_key, private_key)


host_node = init_host()


def init_blockchain():

    if exists(FILENAME):
        return

    # get correct nonce
    block_header = BlockHeader(
        previous_block_hash=None,
        timestamp=get_timestamp("2022/9/22"),
        nonce=672681
    )

    first_block = Block(block_header, BlockData("", False))

    # uncomment to get nonce of 1st block
    # while not first_block.hash.startswith("00000"):
    #     first_block.header.nonce += 1
    #     first_block.hash = first_block.get_hash()
    #
    # print(first_block.header.nonce)
    # print(first_block.hash)
    bc = Blockchain(first_block)
    bc.store_in_memory()


def discover_network():
    if len(host_node.known_host) == 0:
        return

    response = host_node.known_host[0].get('users')
    for user in json.loads(response.text):
        host_node.add_node(NodeDto.from_json(user))

    host_node.broadcast('new-user', {
        "ip": host_node.ip,
        "port": host_node.port,
        "public_key": host_node.public_key.export_key("PEM").decode("utf-8")
    })


print('Initializing blockchain')
init_blockchain()
print('Blockchain initialized !')
print('Discovering network')
discover_network()
print('Network joined !')


@app.route('/new-prediction', methods=['POST'])
def receive_prediction_from_node():
    content = request.json['data']
    sender = request.json['sender']
    try:
        block_data = BlockData.from_json(content)
        block_sender = NodeDto.from_json(sender)
        if not host_node.verify(block_data, block_sender):
            raise ResponseException(403, "Prediction not verified")
        return handle_new_prediction(block_data)
    except ResponseException as e:
        return e.to_response


@app.route('/prediction', methods=['POST'])
def receive_prediction_from_user():  # put application's code here
    content = request.json
    try:
        block_data = BlockData.from_json(content)
        block_data.signature = host_node.sign(block_data)
        return handle_new_prediction(block_data)
    except ResponseException as e:
        return e.to_response


def handle_new_prediction(block_data: BlockData):

    if Blockchain.already_inside(block_data) or block_data in host_node.prediction_to_mine:
        return "Already known", 200

    if host_node.add_prediction_to_mine(block_data):
        host_node.broadcast_prediction(block_data)

    host_node.launch_mining()

    return block_data.to_json, 200


@app.route("/chain", methods=['GET'])
def send_chain():
    blockchain = Blockchain.get_from_memory()
    return jsonify(blockchain.to_list), 200


@app.route("/display-chain", methods=['GET'])
def send_all_chain():
    blockchain = Blockchain.get_from_memory()
    return jsonify(blockchain.all_info), 200


@app.route("/block", methods=['POST'])
def validate_block():
    content = request.json["data"]
    sender = request.json["sender"]
    received_length = content["length"]
    received_block = content["block"]

    prediction = BlockData.from_json(received_block)
    blockchain_base = Blockchain.get_from_memory()
    new_block = BlockDto.from_json(content)
    msg, code = blockchain_base.update(received_block=new_block, length=received_length)
    if code == 200:
        host_node.stop_mining()
        host_node.remove_prediction_to_mine(prediction)
        host_node.launch_mining()
        return "Block accepted", 200
    elif code == 201:
        sender_node = NodeDto.from_json(sender)
        response = sender_node.get('chain')
        if not response.ok:
            return "Error while getting the chain", 400
        current_bc = Blockchain.get_from_memory()
        for model in current_bc.get_models():
            host_node.add_prediction_to_mine(model)

        new_bc = Blockchain.get_from_json(response.json())
        if new_bc.is_valid:
            new_bc.store_in_memory()
            host_node.remove_nodes([model for model in new_bc])
            return "Blockchain replaced", 200
        return "Chain not valid", 406
    return msg, code


@app.route("/users", methods=['GET'])
def get_known_users():
    return jsonify([node.to_dict for node in host_node.known_host])


@app.route("/new-user", methods=['POST'])
def add_new_host():
    content = request.json['data']
    print("received new user")
    host_node.add_node(NodeDto.from_json(content))
    return 'New host added', 201


@app.route("/points", methods=['GET'])
def get_nb_points():
    known_hosts = host_node.known_host
    users_points = {}
    data_prediction = {}
    for known_host in known_hosts:
        users_points[f"{known_host.ip}:{known_host.port}"] = 0
    bc = Blockchain.get_from_memory()
    for block in bc:
        data_hash = block.data_hash
        prediction = block.prediction
        if block.data_hash not in data_prediction.keys():
            data_prediction[data_hash] = [0, 0]

        if prediction:
            data_prediction[data_hash][0] += 1
            points_to_add = data_prediction[data_hash][0]
        else:
            data_prediction[data_hash][1] += 1
            points_to_add = data_prediction[data_hash][1]

        for known_host in known_hosts:
            if host_node.verify(block, known_host):
                users_points[f"{known_host.ip}:{known_host.port}"] += points_to_add - 1
                break

    return jsonify(users_points), 200


@app.route("/debug", methods=['GET'])
def debug():
    blockchain = Blockchain.get_from_memory()
    return jsonify({
        "bc": blockchain.all_info,
        "known-hosts": f"Known users: {[node.base_url for node in host_node.known_host]}",
        "models to mine": f"{[model.to_json for model in host_node.prediction_to_mine]}",
        "miner": f"{host_node.miner}"
    }), 200


if __name__ == '__main__':
    app.run()
