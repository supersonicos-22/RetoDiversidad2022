from commons.utils import get_timestamp, calculate_hash
from models.BlockData import BlockData
import json


class BlockHeader:
    def __init__(self, previous_block_hash: str, timestamp: float = None, nonce: int = None):
        self.previous_block_hash = previous_block_hash
        self.timestamp = get_timestamp() if timestamp is None else timestamp
        self.nonce = 0 if nonce is None else nonce

    def __eq__(self, other: 'BlockHeader') -> bool:
        try:
            assert isinstance(other, BlockHeader)
            assert self.previous_block_hash == other.previous_block_hash
            assert self.timestamp == other.timestamp
            assert self.nonce == other.nonce
            return True
        except AssertionError:
            return False

    @property
    def to_dict(self) -> dict:
        return {
            "previous_block_hash": self.previous_block_hash,
            "timestamp": self.timestamp,
            "nonce": self.nonce,
        }

    def __str__(self):
        return json.dumps(self.to_dict)

    @property
    def to_json(self) -> str:
        return json.dumps(self.to_dict)


class Block:
    def __init__(self, header: BlockHeader, data: BlockData, previous_block: 'Block' = None):
        self.header = header
        self.data = data
        self.hash = self.get_hash()
        self.previous_block = previous_block

    def get_hash(self) -> str:
        header_data = {
            "previous_block_hash": self.header.previous_block_hash,
            "timestamp": self.header.timestamp,
            "data": self.data.to_json,
            "nonce": self.header.nonce
        }

        return calculate_hash(json.dumps(header_data))

    def __eq__(self, other: 'Block') -> bool:
        try:
            assert isinstance(other, Block)
            assert self.header == other.header
            assert self.data == other.data
            assert self.hash == other.hash
            return True
        except AssertionError:
            return False

    def __str__(self):
        return json.dumps({
            "timestamp": self.header.timestamp,
            "hash": self.hash,
            "data": str(self.data)
        })

    @property
    def to_dict(self):
        block_data = {
            "header": self.header.to_dict,
            "data": self.data.to_dict,
            "hash": self.hash
        }
        return block_data

    @property
    def to_json(self) -> str:
        return json.dumps(self.to_dict)
