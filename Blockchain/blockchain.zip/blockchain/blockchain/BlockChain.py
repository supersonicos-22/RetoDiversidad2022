from blockchain.Block import Block, BlockHeader
import json
from blockchain import FILENAME, NUMBER_OF_ZEROS
from node.BlockChainValidation import NewBlock
from models.BlockData import BlockData


class BlockChainIterator:
    def __init__(self, blocks: Block):
        self.current = blocks

    def __iter__(self):
        return self

    def __next__(self):
        if not self.current:
            raise StopIteration
        else:
            item = self.current.data
            self.current = self.current.previous_block
            return item


class Blockchain:
    def __init__(self, blocks: Block):
        self.blocks = blocks

    def __len__(self) -> int:
        i = 1
        current_block = self.blocks
        while current_block.previous_block is not None:
            i += 1
            current_block = current_block.previous_block
        return i

    def __iter__(self):
        return BlockChainIterator(self.blocks)

    @property
    def last_block(self):
        return self.blocks

    def _is_in_chain(self, data):
        current_block = self.blocks
        while current_block.previous_block:
            if data == current_block.data:
                return True
        return False

    def get_models(self):
        models = []
        current_block = self.blocks
        while current_block.previous_block:
            models.append(current_block.data)
            current_block = current_block.previous_block
        models.append(current_block.data)
        return models

    def update(self, received_block: Block, length: int):
        expected_length = len(self)

        if expected_length == length:
            return self.add_block(received_block)
        elif expected_length > length:
            return self.send_chain()
        else:
            return self.replace_chain()

    def add_block(self, received_block: Block):
        new_block = NewBlock(self.blocks)
        new_block.receive(new_block=received_block)
        new_block.validate()
        new_block.add()
        self.blocks = new_block.new_block
        self.store_in_memory()
        return "Transaction success", 200

    def send_chain(self):
        return "Reset your chain", 205

    def replace_chain(self):
        # get back models that are not in the chain and mine them again
        return "Getting new chain", 201

    @property
    def to_list(self) -> list:
        block_list = []
        current_block = self.blocks
        while current_block:
            block_data = {
                "header": current_block.header.to_dict,
                "data": current_block.data.to_dict
            }
            block_list.append(block_data)
            current_block = current_block.previous_block
        return block_list

    @property
    def to_json(self) -> str:
        return json.dumps(self.to_list)

    def store_in_memory(self):
        text = json.dumps(self.to_list).encode("utf-8")
        with open(FILENAME, "wb") as file_obj:
            file_obj.write(text)

    @staticmethod
    def get_from_json(bc_json) -> 'BlockChain':
        block_list = bc_json
        block_object: Block = None
        previous_block: Block = None
        for block_dict in reversed(block_list):
            block_header_str = block_dict.pop("header")
            block_header = BlockHeader(**block_header_str)
            block_data = BlockData(**block_dict["data"])
            block_object = Block(data=block_data, header=block_header)
            block_object.previous_block = previous_block
            previous_block = block_object
        return Blockchain(block_object)

    @staticmethod
    def get_from_memory() -> 'BlockChain':
        with open(FILENAME, "r") as file_obj:
            blocks_text = file_obj.read()
            block_list = json.loads(blocks_text)
            return Blockchain.get_from_json(block_list)

    @staticmethod
    def already_inside(data: BlockData):
        bc = Blockchain.get_from_memory()
        current_block = bc.blocks

        while current_block.previous_block:
            if current_block.data == data:
                return True
            current_block = current_block.previous_block
        if current_block.data == data:
            return True

        return False

    @property
    def all_info(self):
        block_list = []
        current_block = self.blocks
        while current_block:
            block_data = {
                "header": current_block.header.to_dict,
                "data": current_block.data.to_dict,
                "hash": current_block.hash
            }
            block_list.append(block_data)
            current_block = current_block.previous_block
        return block_list

    @property
    def is_valid(self) -> bool:
        try:
            current_block = self.blocks
            while current_block:
                assert current_block.get_hash().startswith(NUMBER_OF_ZEROS * '0')
                if current_block.header.previous_block_hash is not None:
                    assert current_block.header.previous_block_hash == current_block.previous_block.get_hash()
                else:
                    assert current_block.previous_block is None

                current_block = current_block.previous_block
            return True
        except AssertionError:
            return False
