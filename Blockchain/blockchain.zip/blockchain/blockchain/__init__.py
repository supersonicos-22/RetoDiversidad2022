import os
import sys
from dotenv import load_dotenv

load_dotenv()
FILENAME = f"{os.getenv('FILENAME')}{int(sys.argv[3])}"
nboz = os.getenv('NUMBER_OF_ZEROS')
assert nboz.isnumeric(), "NUMBER_OF_ZEROS must be an int"


def _get_number_of_zeros(inboz: int):
    if inboz < 1:
        return 1
    elif inboz > 10:
        return 10
    else:
        return inboz


NUMBER_OF_ZEROS = _get_number_of_zeros(int(nboz))
