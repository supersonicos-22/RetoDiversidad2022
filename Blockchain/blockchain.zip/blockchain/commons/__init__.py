import os

from Crypto.PublicKey import RSA
from dotenv import load_dotenv

load_dotenv()
KNOWN_IP = os.getenv('KNOWN_IP')
file_key = os.getenv('KNOWN_PUB_KEY')
with open(file_key, "rb") as f:
    KNOWN_PUB_KEY = RSA.importKey(f.read())
kp = os.getenv('KNOWN_PORT')
assert kp.isnumeric(), "KNOWN_PORT must be an int"

KNOWN_PORT = int(kp)
