from datetime import datetime
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA


def get_timestamp(date: str = None):
    if date is not None:
        [year, month, day] = date.split('/')
        return datetime.timestamp(datetime(int(year), int(month), int(day)))
    return datetime.timestamp(datetime.now())


def calculate_hash(data) -> str:
    data = bytearray(data, "utf-8")
    new_hash = SHA256.new()
    new_hash.update(data)
    return new_hash.hexdigest()


def generate_key_pair() -> (str, str):
    key = RSA.generate(2048)
    private_key = key.export_key("PEM")
    public_key = key.publickey().export_key("PEM")
    return public_key, private_key
