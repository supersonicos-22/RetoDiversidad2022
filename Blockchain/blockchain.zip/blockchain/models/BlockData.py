import json
from typing import Union
from models.ResponseException import ResponseException


class BlockData:
    def __init__(self, data_hash: str, prediction: bool, signature: Union[str, bytes] = "None"):
        self.data_hash = data_hash
        self.prediction = prediction
        self.signature = signature.encode('utf-8') if isinstance(signature, str) else bytes(signature)

    @staticmethod
    def validate(received_json: dict):
        try:
            assert "data_hash" in received_json, "\"data_hash\" attribute missing"
            assert isinstance(received_json["data_hash"], str), "\"data_hash\" must be a string"
            assert "prediction" in received_json, "\"prediction\" attribute missing"
            assert isinstance(received_json["prediction"], bool), "\"prediction\" must be a boolean"
            if "signature" in received_json:
                assert isinstance(received_json["signature"], str), "\"signature\" must be a string"
        except AssertionError as e:
            raise e

    @staticmethod
    def from_json(received_json: dict) -> 'BlockData':
        try:
            BlockData.validate(received_json)
            block_data = BlockData(received_json["data_hash"], received_json["prediction"])
            if "signature" in received_json:
                block_data.signature = str(received_json["signature"]).encode("utf-8")
            else:
                block_data.signature = "None".encode('utf-8')
            return block_data
        except AssertionError as e:
            raise ResponseException(400, str(e))

    def get_test(self) -> str:
        return self.data_hash

    @property
    def to_dict(self) -> dict:
        return {
            "data_hash": self.data_hash,
            "prediction": self.prediction,
            "signature": self.signature.decode("utf-8")
        }

    @property
    def useful_infos(self):
        return {
            "data_hash": self.data_hash,
            "prediction": self.prediction,
        }

    @property
    def to_json(self) -> str:
        return json.dumps(self.to_dict)

    def __str__(self) -> str:
        return json.dumps(self.to_dict)

    def same_article_from_same_user(self, other: 'BlockData'):
        try:
            assert self.data_hash == other.data_hash
            assert self.signature == other.signature
            return True
        except AssertionError:
            return False

    def __eq__(self, other) -> bool:
        try:
            assert isinstance(other, BlockData)
            assert self.data_hash == other.data_hash
            assert self.prediction == other.prediction
            assert self.signature == other.signature
            return True
        except AssertionError:
            return False
