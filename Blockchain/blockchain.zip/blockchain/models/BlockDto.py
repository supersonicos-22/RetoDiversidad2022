from blockchain.Block import Block, BlockHeader
from models.BlockData import BlockData
from models.ResponseException import ResponseException


class BlockDto:
    def __init__(self, block_header: BlockHeader, block_data: BlockData):
        self.block_header = block_header
        self.block_data = block_data

    @staticmethod
    def validate(received_json: dict):
        try:
            assert "header" in received_json, "\"header\" attribute missing"
            assert isinstance(received_json["header"], dict), "\"header\" must be a dict"

            assert "previous_block_hash" in received_json["header"], "\"previous_block_hash\" is missing in header"
            assert isinstance(received_json["header"]["previous_block_hash"], str), "\"previous_block_hash\" must be a string"
            assert "timestamp" in received_json["header"], "\"timestamp\" is missing in header"
            assert isinstance(received_json["header"]["timestamp"], float), "\"timestamp\" must be a float"
            assert "nonce" in received_json["header"], "\"previous_block_hash\" is missing in header"
            assert isinstance(received_json["header"]["nonce"], int), "\"nonce\" must be a int"

            assert "block" in received_json, "\"block\" attribute missing"
            BlockData.validate(received_json["block"])
        except AssertionError as e:
            raise e

    @staticmethod
    def from_json(received_json: dict):
        try:
            BlockDto.validate(received_json)
            block_header = BlockHeader(**received_json["header"])
            data = received_json["block"]
            block_data = BlockData(data["data_hash"], data["prediction"], data["signature"])
            return Block(block_header, block_data)
        except AssertionError as e:
            raise ResponseException(400, str(e))
