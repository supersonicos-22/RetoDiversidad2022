from Crypto.PublicKey import RSA

from models.ResponseException import ResponseException
from node.OtherNode import OtherNode


class NodeDto:
    @staticmethod
    def validate(received_json: dict):
        try:
            assert "ip" in received_json, "\"ip\" is missing"
            assert isinstance(received_json["ip"], str), "\"ip\" must be a string"
            assert "port" in received_json, "\"port\" is missing"
            assert isinstance(received_json["port"], int), "\"port\" must be an int"
            assert "public_key" in received_json, "\"public_key\" is missing"
            assert isinstance(received_json["public_key"], str), "\"public_key\" must be a str"
        except AssertionError as e:
            raise e

    @staticmethod
    def from_json(received_json: dict) -> OtherNode:
        try:
            NodeDto.validate(received_json)
            ip, port = received_json['ip'], received_json['port']
            public_key = RSA.importKey(str(received_json['public_key']).encode("utf-8"))
            return OtherNode(ip, port, public_key)
        except AssertionError as e:
            raise ResponseException(400, str(e))
