class ResponseException(Exception):
    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message

    @property
    def to_response(self):
        return self.message, self.code
