from blockchain.Block import Block
from models.ResponseException import ResponseException
from blockchain import NUMBER_OF_ZEROS


class NewBlock:
    def __init__(self, last_block: Block):
        self.last_block = last_block
        self.new_block = None

    def receive(self, new_block: Block):
        self.new_block = new_block
        try:
            assert self.last_block.hash == self.new_block.header.previous_block_hash
        except AssertionError:
            raise ResponseException(400, "Previous block provided is not the most recent block")

    def validate(self):
        self._validate_hash()
        # validate signature

    def _validate_hash(self):
        new_block_hash = self.new_block.get_hash()
        number_of_zeros_string = str(0) * NUMBER_OF_ZEROS
        try:
            assert new_block_hash.startswith(number_of_zeros_string)
        except AssertionError:
            raise ResponseException(400, "Proof of work validation failed")

    def add(self):
        self.new_block.previous_block = self.last_block
