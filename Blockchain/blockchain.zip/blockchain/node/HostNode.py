import base64
from typing import Optional

from Crypto.PublicKey.RSA import RsaKey

from node.Node import Node
from node.OtherNode import OtherNode
from commons import KNOWN_IP, KNOWN_PORT, KNOWN_PUB_KEY
from blockchain.Block import Block
from blockchain.BlockChain import Blockchain
from threading import Lock, Thread
from models.BlockData import BlockData
from node.ProofOfWork import ProofOfWork
from Crypto.Signature import PKCS1_v1_5
from Crypto.Hash import SHA256
from Crypto.PublicKey import RSA


class HostNode(Node):
    def __init__(self, ip: str, port: int, public_key: RsaKey, private_key: RsaKey):
        super().__init__(ip, port, public_key)
        self.private_key = private_key
        self.public_key = public_key

        if ip == KNOWN_IP and port == KNOWN_PORT:
            self.known_host = []
        else:
            self.known_host = [OtherNode(KNOWN_IP, int(KNOWN_PORT), KNOWN_PUB_KEY)]
        self.predictions_sent = 0
        self.prediction_to_mine = []
        self.lock_pred = Lock()
        self.lock_node = Lock()
        self.lock_model = Lock()
        self.miner = True if input("Will this node mine ? (Y/N)") == "Y" else False
        self.mining_thread: Optional[Thread] = None
        self.pof: Optional[ProofOfWork] = None

    def add_node(self, new_user: OtherNode):
        with self.lock_node:
            if new_user not in self.known_host and not self._is_known_host(new_user):
                self.known_host.append(new_user)

    @staticmethod
    def _is_known_host(other: OtherNode):
        return other.ip == KNOWN_IP and other.port == KNOWN_PORT

    def remove_nodes(self, users_to_remove: list[OtherNode]):
        with self.lock_node:
            for user_to_remove in users_to_remove:
                if user_to_remove in self.known_host:
                    self.known_host.remove(user_to_remove)

    def has_already_voted(self, block_data: BlockData) -> bool:
        bc = Blockchain.get_from_memory()
        for block in bc:
            if block_data.same_article_from_same_user(block):
                return True
        return False

    def add_prediction_to_mine(self, block_data: BlockData) -> bool:
        with self.lock_model:
            if not self.has_already_voted(block_data) and block_data not in self.prediction_to_mine:
                self.prediction_to_mine.append(block_data)
                return True
        return False

    def remove_prediction_to_mine(self, block_data: BlockData):
        with self.lock_model:
            if block_data in self.prediction_to_mine:
                self.prediction_to_mine.remove(block_data)

    def broadcast_block(self, block: Block):
        block_content = {
            "header": block.header.to_dict,
            "block": block.data.to_dict,
            "length": len(Blockchain.get_from_memory())
        }
        self.update_blockchain(block)
        self.remove_prediction_to_mine(block.data)
        self.broadcast('block', block_content)

    def broadcast_prediction(self, model: BlockData):
        with self.lock_pred:
            model_content = {
                "data_hash": model.data_hash,
                "prediction": model.prediction,
                "signature": model.signature.decode("utf-8")
            }

        self.broadcast('new-prediction', model_content)

    def broadcast(self, path: str, data: dict):
        node_to_remove: list[OtherNode] = []
        for node in self.known_host:
            response = node.post(endpoint=path, data=data, sender=self)
            if response is None:
                node_to_remove.append(node)

        self.remove_nodes(node_to_remove)

    def launch_mining(self):
        if not self.miner or self.mining_thread is not None:
            return

        prediction_to_mine = self.prediction_to_mine[0]
        mining_process = Thread(target=self.mine_and_send, args=(prediction_to_mine, ))
        mining_process.start()

    def mine_and_send(self, data: BlockData):
        self.pof = ProofOfWork()
        block, valid = self.pof.create_new_block(data)
        if valid:
            self.broadcast_block(block)

    def stop_mining(self):
        if self.mining_thread is not None and self.mining_thread.is_alive():
            self.pof.mining = False
            self.mining_thread.join()
        self.pof = None
        self.mining_thread = None

    @staticmethod
    def update_blockchain(block: Block):
        blockchain_base = Blockchain.get_from_memory()
        blockchain_base.add_block(block)

    def sign(self, prediction: BlockData) -> bytes:
        signer = PKCS1_v1_5.new(self.private_key)
        digest = SHA256.new(prediction.data_hash.encode("utf-8"))
        return base64.b64encode(signer.sign(digest))

    def verify(self, prediction: BlockData, sender: OtherNode) -> bool:
        sender: OtherNode = list(filter(lambda node: node.ip == sender.ip and node.port == sender.port, self.known_host))[0]
        verifier = PKCS1_v1_5.new(sender.public_key)
        digest = SHA256.new(prediction.data_hash.encode("utf-8"))
        try:
            verifier.verify(digest, base64.b64decode(prediction.signature))
            return True
        except ValueError:
            return False
