import json
from typing import Optional

import requests
from Crypto.PublicKey.RSA import RsaKey


class Node:
    def __init__(self, ip: str, port: int, public_key: RsaKey):
        self.ip = ip
        self.port = port
        self.base_url = f"http://{ip}:{port}/"
        self.public_key = public_key

    @property
    def to_dict(self):
        return {
            "ip": self.ip,
            "port": self.port,
            "public_key": self.public_key.export_key().decode("utf-8")
        }

    @property
    def to_json(self):
        return json.dumps(self.to_dict)

    def post(self, endpoint: str, data: dict, sender: 'Node') -> Optional[requests.Response]:
        url = f"{self.base_url}{endpoint}"
        try:
            req_return = requests.post(url, json={"data": data, "sender": sender.to_dict})
            req_return.raise_for_status()
            return req_return
        except requests.ConnectionError:
            print(f"Couldn't reach {self.ip}:{self.port}")
            return None
        except Exception as e:
            print(e)
            return None

    def get(self, endpoint: str) -> requests.Response:
        url = f"{self.base_url}{endpoint}"
        req_return: requests.Response = None
        try:
            req_return = requests.get(url)
            req_return.raise_for_status()
        except requests.ConnectionError:
            print(f"Couldn't reach {self.ip}:{self.port}")
        finally:
            return req_return

    def __eq__(self, other) -> bool:
        try:
            assert isinstance(other, Node)
            assert self.ip == other.ip
            assert self.port == other.port
            assert self.public_key == other.public_key
            return True
        except AssertionError:
            return False
