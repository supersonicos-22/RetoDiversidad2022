from Crypto.PublicKey.RSA import RsaKey

from node.Node import Node


class OtherNode(Node):
    def __init__(self, ip: str, port: int, public_key: RsaKey):
        super().__init__(ip, port, public_key)
