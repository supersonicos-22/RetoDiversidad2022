from blockchain.BlockChain import Blockchain
from blockchain.Block import Block, BlockHeader
import json
from commons.utils import calculate_hash, get_timestamp
from blockchain import NUMBER_OF_ZEROS
from models.BlockData import BlockData


class ProofOfWork:
    def __init__(self):
        self.blockchain = Blockchain.get_from_memory()
        self.new_block: Block = None
        self.mining = True

    def get_nonce(self) -> (int, bool):
        block_hash = ""
        nonce = self.new_block.header.nonce
        starting_zeros = str(0) * NUMBER_OF_ZEROS
        while self.mining and not block_hash.startswith(starting_zeros):
            nonce = nonce + 1
            block_content = {
                "previous_block_hash": self.new_block.header.previous_block_hash,
                "timestamp": self.new_block.header.timestamp,
                "data": self.new_block.data.to_json,
                "nonce": nonce
            }
            block_hash = calculate_hash(json.dumps(block_content))
        return nonce, block_hash.startswith(starting_zeros)

    def create_new_block(self, data: BlockData) -> (Block, bool):
        block_header = BlockHeader(
            previous_block_hash=self.blockchain.last_block.hash,
            timestamp=get_timestamp(),
            nonce=0
        )
        self.new_block = Block(block_header, data)
        self.new_block.header.nonce, valid = self.get_nonce()
        return self.new_block, valid
