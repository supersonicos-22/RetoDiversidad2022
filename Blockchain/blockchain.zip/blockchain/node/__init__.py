import os
import sys
from dotenv import load_dotenv

load_dotenv()
PUB_KEY_FILENAME = f"{os.getenv('PUB_KEY_FILENAME')}{int(sys.argv[3])}.pem"
PRIVATE_KEY_FILENAME = f"{os.getenv('PRIVATE_KEY_FILENAME')}{int(sys.argv[3])}.pem"
